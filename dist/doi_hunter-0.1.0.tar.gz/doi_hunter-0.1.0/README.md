# DOI Hunter

DOI Hunter is a command-line tool for downloading research papers from Sci-Hub using DOIs or paper titles.

## Installation

You can install the package using `pip`:

```bash
pip install doi_hunter
